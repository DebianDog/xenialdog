package CGI::HTML::Functions;

use strict;
use warnings;

# nothing here yet... may move functions here in the long term

1;
